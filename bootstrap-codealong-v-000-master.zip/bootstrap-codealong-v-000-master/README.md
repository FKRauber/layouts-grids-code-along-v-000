# Bootstrap Code-Along

<iframe width="640" height="480" src="//www.youtube.com/embed/o5UCDvaNLd8?rel=0&modestbranding=1" frameborder="0" allowfullscreen></iframe>

<p><a href="https://www.youtube.com/watch?v=o5UCDvaNLd8">Bootstrap Code-Along</a>.</p>

Note: If you are using the Learn IDE, you'll have to download the files to your local computer and unzip them. Then, in the Learn IDE, right click on the folder where you would like to store them and then use the Import File option to bring them into the Learn IDE. Now you'll be able to see them in the file tree and in the terminal.

Note too that your file structure might differ from what's in the video. That's okay! Just code along as best you can — we know that you're quite capable of filling in any gaps!

Finally, because this is a simple code-along, you won't actually have to submit anything at the end (unlike in the video).

(And yes, we'll be updating the video ASAP!)

<p data-visibility='hidden'>View <a href='https://learn.co/lessons/bootstrap-codealong' title='Bootstrap Code-Along'>Bootstrap Code-Along</a> on Learn.co and start learning to code for free.</p>
